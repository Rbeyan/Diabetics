from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import CheckpointCallback
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.vec_env import VecNormalize, SubprocVecEnv
from stable_baselines3.common.env_checker import check_env
from env.simglucose_gym_env_2 import T1DAdultSimEnv
from reward.custom_rewards import no_negativity, partial_negativityV2, risk_diff
import torch as th
import warnings
import sys
print(sys.path)

def main():
    warnings.filterwarnings("ignore", category=DeprecationWarning) 
    warnings.simplefilter(action='ignore', category=FutureWarning)
    
    # Adjusted total timesteps
    total_time_steps = 256
    save_folder = 'C:\\Users\\nicol\\OneDrive - Universitaet Bern\\Dokumente\\unibe\\BME\\Sem_5\\Diabetes Mgmt\\Code\\diabetes-RL-project\\train\\new_models'

    checkpoint_callback = CheckpointCallback(save_freq=1024, save_path=save_folder,
                                             name_prefix="rl_model2")

    vec_env_kwargs = {'start_method': 'spawn'}
    env_kwargs = {'reward_fun': risk_diff}
    env = make_vec_env(T1DAdultSimEnv, n_envs=10, vec_env_cls=SubprocVecEnv,
                       vec_env_kwargs=vec_env_kwargs, env_kwargs=env_kwargs)

    # Updated network architecture
    policy_kwargs = {
        'net_arch': dict(pi=[64, 64, 64], vf=[64, 64, 64])
    }

    # Updated model configuration
    model = PPO('MlpPolicy', env, verbose=1,
                n_steps=total_time_steps, learning_rate=1e-4, ent_coef=0.01,
                policy_kwargs=policy_kwargs, seed=465,
                gamma=0.9, n_epochs=10)  # Adjusted learning rate, entropy, gamma, and epochs

    # Increased total timesteps for training
    model.learn(total_timesteps=500000, callback=[checkpoint_callback])
    model.save(save_folder)

if __name__ == "__main__":
    main()





