"""
Changes that have been made:
- added: T1DAdolescentSimEnv, T1DChildSimEnv
- changes: discrete parameters adjusted
"""

import random
import torch
import torch.nn as nn
import sys
from simglucose.simulation.env import T1DSimEnv as _T1DSimEnv
from simglucose.patient.t1dpatient import T1DPatient
from simglucose.sensor.cgm import CGMSensor
from simglucose.actuator.pump import InsulinPump
from simglucose.simulation.scenario_gen import RandomScenario
from simglucose.controller.base import Action
import pandas as pd
import numpy as np
import pkg_resources
import gym
from gym import error, spaces, utils
from gym.utils import seeding
from datetime import datetime

PATIENT_PARA_FILE = pkg_resources.resource_filename(
    'simglucose', 'params/vpatient_params.csv')

patient_params = pd.read_csv(PATIENT_PARA_FILE)
patient_names = patient_params['Name'].values

#Implementation of meal detection model

class LSTMModel(torch.nn.Module):
    def __init__(self, input_size, hidden_size):
        super(LSTMModel, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, batch_first=True).float()  # Set the LSTM layer to float precision
        self.fc1 = nn.Linear(hidden_size, 128).float()
        self.fc2 = nn.Linear(128, 1).float()
        self.relu = nn.ReLU().float()
        self.sigmoid = nn.Sigmoid().float()

    def forward(self, x):
        out, _ = self.lstm(x)
        out = self.relu(out[:, -1, :])  # Take the last output in the sequence
        out = self.fc1(out)
        out = self.relu(out)
        out = self.fc2(out)
        out = self.sigmoid(out)
        return out

class T1DAdultSimEnv(gym.Env):
    '''
    A wrapper of simglucose.simulation.env.T1DSimEnv to support gym API
    '''
    metadata = {'render.modes': ['human']}

    SENSOR_HARDWARE = 'Dexcom'
    INSULIN_PUMP_HARDWARE = 'Insulet'

    def __init__(self, patient_name=None, reward_fun=None, seed=None):
        '''
        patient_name must be 'adolescent#001' to 'adolescent#010',
        or 'adult#001' to 'adult#010', or 'child#001' to 'child#010'
        '''
        # have to hard code the patient_name, gym has some interesting
        # error when choosing the patient
        if patient_name is None:
            # patient_name = 'adolescent#001'
            adult_patients = [p for p in patient_names if "adult" in p]
            patient_name = random.choice(adult_patients)
            print(patient_name)
        self.patient_name = patient_name
        self.reward_fun = reward_fun
        self.np_random, _ = seeding.np_random(seed=seed)
        self.env, _, _, _ = self._create_env_from_random_state()
        # ToDo: Correct observation space

        

    def step(self, action): # adjusted self function
        act = Action(basal=action, bolus=0)
        # Simulate one step in the environment
        observation, reward, done, info = self.env.step(act, reward_fun=self.reward_fun)

        # Meal detection logic
        series_length = 30
        cgm_values = self.get_cgm_values(observation) 

        # ToDo: Some preprocessing such that input data is same as training input data!

        if len(cgm_values) >= series_length:
            normalized_cgm_values = self.normalize_data(cgm_values[-series_length:])  
            model_input = torch.tensor([normalized_cgm_values], dtype=torch.float32).unsqueeze(-1)

            with torch.no_grad():
                meal_prediction = self.model(model_input)

            # Set meal_detect based on the prediction
            meal_detect = 1 if meal_prediction.item() > 0.7 else 0 # ToDo: This theshhold ok???
            observation = np.append(observation, meal_detect) # ToDo: Check for correct observation space

        return observation, reward, done, info

   

    def reset(self):
        self.env, _, _, _ = self._create_env_from_random_state()
        obs, _, _, _ = self.env.reset()
        return obs

    def seed(self, seed=None):
        self.np_random, seed1 = seeding.np_random(seed=seed)
        self.env, seed2, seed3, seed4 = self._create_env_from_random_state()
        return [seed1, seed2, seed3, seed4]

    def _create_env_from_random_state(self):
        # Derive a random seed. This gets passed as a uint, but gets
        # checked as an int elsewhere, so we need to keep it below
        # 2**31.
        seed2 = seeding.hash_seed(self.np_random.randint(0, 1000)) % 2 ** 31
        seed3 = seeding.hash_seed(seed2 + 1) % 2 ** 31
        seed4 = seeding.hash_seed(seed3 + 1) % 2 ** 31

        hour = self.np_random.randint(low=0.0, high=24.0)
        start_time = datetime(2018, 1, 1, hour, 0, 0)
        patient = T1DPatient.withName(self.patient_name, random_init_bg=True, seed=seed4)
        sensor = CGMSensor.withName(self.SENSOR_HARDWARE, seed=seed2)
        scenario = RandomScenario(start_time=start_time, seed=seed3)
        pump = InsulinPump.withName(self.INSULIN_PUMP_HARDWARE)
        env = _T1DSimEnv(patient, sensor, pump, scenario)
        return env, seed2, seed3, seed4

    def render(self, mode='human', close=False):
        self.env.render(close=close)

    @property
    def action_space(self):
        ub = self.env.pump._params['max_basal']
        return spaces.Box(low=0, high=ub, shape=(1,))

    @property
    def observation_space(self):
        return spaces.Box(low=0, high=np.inf, shape=(1,))

