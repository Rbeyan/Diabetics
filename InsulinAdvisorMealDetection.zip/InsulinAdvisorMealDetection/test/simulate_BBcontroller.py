import sys
sys.path.append('C:/Users/nicol/OneDrive - Universitaet Bern/Dokumente/unibe/BME/Sem_5/Diabetes Mgmt/Code/InsulinAdvisorMealDetection/test')
import glob
import os
from datetime import datetime, timedelta
from warnings import simplefilter
import numpy as np 

#os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
simplefilter(action='ignore', category=FutureWarning)
simplefilter(action='ignore', category=UserWarning)

from simglucose.actuator.pump import InsulinPump
#from simglucose.controller.pid_ctrller import PIDController
#from controller import PPOController
from simglucose_local.simglucose.controller.basal_bolus_ctrller_2 import BBController
#from simglucose_local.simglucose.controller.basal_bolus_ctrller import BBController
from simglucose.patient.t1dpatient import T1DPatient
from simglucose.sensor.cgm import CGMSensor
from simglucose.simulation.env import T1DSimEnv
from simglucose.simulation.scenario import CustomScenario
from simglucose.simulation.sim_engine import SimObj, sim
#from train.env.simglucose_gym_env import T1DAdultSimEnv, T1DSimHistoryEnv, T1DSimDiffEnv
#from train.reward.custom_rewards import partial_negativity

def create_scenario(_base_scen, _sim_days):
    repeat_scen = []
    vary_scen = []
    for simDay in range(_sim_days):
        for time, mealsize in _base_scen:
            repeat_scen.append((24 * simDay + time, mealsize))
    return CustomScenario(start_time=start_time, scenario=repeat_scen), repeat_scen


# BB controller without variance
controller = BBController()

now = datetime.now()
start_time = datetime.combine(now.date(), datetime.min.time())
path = r'C:\\Users\\nicol\\OneDrive - Universitaet Bern\\Dokumente\\unibe\\BME\\Sem_5\\Diabetes Mgmt\\Code\\InsulinAdvisorMealDetection\\test\\BB_results'

patient = T1DPatient.withName('adult#005')
sensor = CGMSensor.withName('Dexcom', seed=1)
pump = InsulinPump.withName('Insulet')

# Set base scenario and add variability and repeat for as many days as necessary
sim_days = 7
base_scen = [(7, 70), (10, 30), (14, 110), (21, 90)]
scenario, mod_scen = create_scenario(base_scen, sim_days)
env = T1DSimEnv(patient, sensor, pump, scenario)

s1 = SimObj(env, controller, timedelta(days=sim_days), animate=True, path=path)
sim(s1)

































#controller = PPOController(0, latest_saved_model)
controller = BBController


now = datetime.now()
start_time = datetime.combine(now.date(), datetime.min.time())
path = './results'

patient = T1DPatient.withName('adult#002')
sensor = CGMSensor.withName('Dexcom', seed=1)
pump = InsulinPump.withName('Insulet')

scen = [(7, 70), (10, 30), (14, 110), (21, 90)]
scenario = CustomScenario(start_time=start_time, scenario=scen)
env = T1DSimEnv(patient, sensor, pump, scenario)

s1 = SimObj(env, controller, timedelta(days=1), animate=True, path=path)

sim(s1)

#pid_controller = PIDController(P=-0.0001, I=-0.000000275, D=-0.1)
#s2 = SimObj(env, pid_controller, timedelta(days=1), animate=True, path=path)
#sim(s2)
