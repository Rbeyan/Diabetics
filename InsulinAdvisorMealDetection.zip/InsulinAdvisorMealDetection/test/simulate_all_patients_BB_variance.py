"""
Changes that have been made:
- our implementation
"""
import sys
sys.path.append('C:/Users/nicol/OneDrive - Universitaet Bern/Dokumente/unibe/BME/Sem_5/Diabetes Mgmt/Code/InsulinAdvisorMealDetection/test')
import os
import copy
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import pkg_resources

from simglucose.simulation.env import T1DSimEnv
from simglucose.controller.basal_bolus_ctrller import BBController
from simglucose.sensor.cgm import CGMSensor
from simglucose.actuator.pump import InsulinPump
from simglucose.patient.t1dpatient import T1DPatient
from simglucose.simulation.scenario import CustomScenario
from simglucose.simulation.sim_engine import SimObj, batch_sim

# import patient parameters
PATIENT_PARA_FILE = pkg_resources.resource_filename(
    'simglucose', 'params/vpatient_params.csv')

# define start date as hour 0 of the current day
now = datetime.now()
start_time = datetime.combine(now.date(), datetime.min.time())


def create_result_folder():
    """create results folder"""
    _folder_name = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    _path = os.path.join(os.path.abspath('C:/Users/nicol/OneDrive - Universitaet Bern/Dokumente/unibe/BME/Sem_5/Diabetes Mgmt/Code/InsulinAdvisorMealDetection/test/BB_results_all'), _folder_name)
    os.makedirs(_path, exist_ok=True)
    return _path


def build_envs(name, _scenario):
    """create environments for simulation"""
    patient = T1DPatient.withName(name)
    sensor = CGMSensor.withName('Dexcom', seed=1)
    pump = InsulinPump.withName('Insulet')
    scen = copy.deepcopy(_scenario)
    env = T1DSimEnv(patient, sensor, pump, scen)
    return env


def create_scenario(_base_scen, _sim_days, vary=True):
    """Create scenario with variability"""
    repeat_scen = []
    vary_scen = []
    for simDay in range(_sim_days):
        for time, mealsize in _base_scen:
            repeat_scen.append((24 * simDay + time, mealsize))
    if vary:
        for meal, vals in enumerate(repeat_scen):
            time, CHO = vals
            time += np.random.normal(0.0, 0.25)
            if (meal - 1) % 4:
                CHO += np.random.normal(0.0, 10)
            else:
                CHO += np.random.normal(0.0, 5)
            vary_scen.append((float(f'{time:.2f}'), float(f'{CHO:.2f}')))
        return CustomScenario(start_time=start_time, scenario=vary_scen), vary_scen
    return CustomScenario(start_time=start_time, scenario=repeat_scen), repeat_scen


def write_log(_envs, _patient_names, _base_scen, _mod_scen, save_path):
    """Generate log file containing info to simulation"""
    log = ['patient name: ', str(_patient_names),
           'sensor: ', _envs[0].sensor.name,
           'pump: ', _envs[0].pump._params[0],
           'base scen: ', str(_base_scen),
           'scen: ', str(_mod_scen),
           'controller: ', 'BBController']

    with open(os.path.join(save_path, 'log.txt'), 'w') as f:
        f.write('\n'.join(log))


def select_patients(_patient_group='All'):
    """Select patients to run simulation for"""
    patient_params = pd.read_csv(PATIENT_PARA_FILE)
    all_patients = list(patient_params['Name'].values)
    if _patient_group == 'All':
        return all_patients
    elif _patient_group == 'Adolescents':
        return all_patients[:10]
    elif _patient_group == 'Adults':
        return all_patients[10:20]
    elif _patient_group == 'Children':
        return all_patients[20:30]


if __name__ == '__main__':
    path = create_result_folder()
    sim_days = 7
    final_results = pd.DataFrame()

    # Define base scenario
    base_scen = [(7, 70), (10, 30), (14, 110), (21, 90)]
    scenario, mod_scen = create_scenario(base_scen, sim_days, vary=True)

    # Patient groups
    patient_groups = ['Adolescents', 'Adults', 'Children']

    # Run in batches of 10 because my PC wouldn't do 30 patients in parallel...

    for group in patient_groups:
        # Select patients for the current group
        patient_names = select_patients(group)
        
        # Create environment for each patient
        envs = [build_envs(patient, scenario) for patient in patient_names]

        # Create BBController instances for each environment
        controllers = [BBController() for _ in range(len(envs))]

        # Create simulation objects for the current group
        sim_instances = [
            SimObj(env, ctrl, timedelta(days=sim_days), animate=False, path=path)
            for (env, ctrl) in zip(envs, controllers)
        ]

        # Run batch simulation for the current group
        results = batch_sim(sim_instances, parallel=True)

        # Concatenate results into the final DataFrame
        group_results = pd.concat(results, keys=[s.env.patient.name for s in sim_instances])
        final_results = pd.concat([final_results, group_results])

        # Write logs for the current group
        write_log(envs, patient_names, base_scen, mod_scen, path)

    # After all groups are simulated, process and save the combined results
    final_results_path = os.path.join('C:/Users/nicol/OneDrive - Universitaet Bern/Dokumente/unibe/BME/Sem_5/Diabetes Mgmt/Code/InsulinAdvisorMealDetection/test/BB_results_all', 'combined_results.csv')
    final_results.to_csv(final_results_path)


