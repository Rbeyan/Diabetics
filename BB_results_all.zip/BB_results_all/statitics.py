import pandas as pd
import os
import glob

def calculate_mean_percentages(base_directory, group_pattern):
    # Define the categories for CGM readings
    def categorize_cgm(cgm_value):
        if 70 <= cgm_value <= 180:
            return 'TIR'
        elif 180 < cgm_value <= 250:
            return 'TAR'
        elif 50 <= cgm_value < 70:
            return 'TBR'
        elif cgm_value > 250:
            return 'THI'
        elif cgm_value < 50:
            return 'TLO'
        else:
            return 'Other'

    # Initialize a dictionary to hold the percentages
    label_percentages = {'TIR': [], 'TAR': [], 'TBR': [], 'THI': [], 'TLO': []}
    files = glob.glob(os.path.join(base_directory, group_pattern))
    for file in files:
        df = pd.read_csv(file)
        df['Category'] = df['CGM'].apply(categorize_cgm)
        total_readings = len(df)
        category_counts = df['Category'].value_counts(normalize=True) * 100
        percentages = category_counts.to_dict()
        for label in label_percentages:
            label_percentages[label].append(percentages.get(label, 0))

    # Calculate the mean of the percentages for each category
    mean_percentages = {label: pd.Series(percentages).mean() for label, percentages in label_percentages.items()}
    return mean_percentages

# Directories for the two sets of data
base_directory_set1 = 'C:/Users/nicol/OneDrive - Universitaet Bern/Dokumente/unibe/BME/Sem_5/Diabetes Mgmt/Code/InsulinAdvisorMealDetection/test/BB_results_all/BB_normal'
base_directory_set2 = 'C:/Users/nicol/OneDrive - Universitaet Bern/Dokumente/unibe/BME/Sem_5/Diabetes Mgmt/Code/InsulinAdvisorMealDetection/test/BB_results_all/BB_variance'

# The patterns to match CSV files for each patient group
patient_groups = ['adult*.csv', 'adolescent*.csv', 'child*.csv']

# Initialize a dictionary to hold overall mean differences
overall_mean_differences = {label: 0 for label in ['TIR', 'TAR', 'TBR', 'THI', 'TLO']}

# Process each patient group for both sets and calculate differences
for group_pattern in patient_groups:
    print(f"\nProcessing {group_pattern}:")

    mean_percentages_set1 = calculate_mean_percentages(base_directory_set1, group_pattern)
    mean_percentages_set2 = calculate_mean_percentages(base_directory_set2, group_pattern)
    
    mean_percentage_differences = {label: mean_percentages_set1[label] - mean_percentages_set2[label] for label in mean_percentages_set1}
    
    # Aggregate the differences for overall mean calculation
    for label in overall_mean_differences:
        overall_mean_differences[label] += mean_percentage_differences[label]

    print(f"Mean percentages for Set 1 ({group_pattern}):")
    print(mean_percentages_set1)
    print(f"Mean percentages for Set 2 ({group_pattern}):")
    print(mean_percentages_set2)
    print(f"Differences in mean percentages between the two sets ({group_pattern}):")
    print(mean_percentage_differences)

# Calculate overall mean differences
overall_mean_differences = {label: diff / len(patient_groups) for label, diff in overall_mean_differences.items()}
print("\nOverall Mean Differences across all patient groups:")
print(overall_mean_differences)





















