import torch
import torchinfo
from torchinfo import summary
import torch.nn as nn
import torch.optim as optim
from torchviz import make_dot
import numpy as np
import os
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, precision_recall_curve, roc_auc_score, average_precision_score
from imblearn.over_sampling import SMOTE
from sklearn.metrics import accuracy_score

# Set seed for reproducibility
torch.manual_seed(42)

# Functions
def recall_m(y_true, y_pred):
    true_positives = torch.sum(torch.round(torch.clip(y_true * y_pred, 0, 1)))
    possible_positives = torch.sum(torch.round(torch.clip(y_true, 0, 1)))
    recall = true_positives / (possible_positives + 1e-7)
    return recall

def precision_m(y_true, y_pred):
    true_positives = torch.sum(torch.round(torch.clip(y_true * y_pred, 0, 1)))
    predicted_positives = torch.sum(torch.round(torch.clip(y_pred, 0, 1)))
    precision = true_positives / (predicted_positives + 1e-7)
    return precision

def f1_m(y_true, y_pred):
    precision = precision_m(y_true, y_pred)
    recall = recall_m(y_true, y_pred)
    return 2 * ((precision * recall) / (precision + recall + 1e-7))

class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(LSTMModel, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, batch_first=True).float()  # Set the LSTM layer to float precision
        self.fc1 = nn.Linear(hidden_size, 128).float()
        self.fc2 = nn.Linear(128, 1).float()
        self.relu = nn.ReLU().float()
        self.sigmoid = nn.Sigmoid().float()

    def forward(self, x):
        out, _ = self.lstm(x)
        out = self.relu(out[:, -1, :])  # Take the last output in the sequence
        out = self.fc1(out)
        out = self.relu(out)
        out = self.fc2(out)
        out = self.sigmoid(out)
        return out


def split_data(cgm, insulin, n_steps):
    data = []
    labels = []
    for i in range(0, len(cgm) - 100):
        end_ix = i + n_steps
        if end_ix > len(cgm) - 1:
            break
        offset = 15
        i_off = i + offset
        end_ix_off = end_ix + offset

        seq_x = cgm[i_off:end_ix_off]
        data.append(seq_x)
        seq_y = any(insulin[i:end_ix] != 0)
        labels.append(seq_y)
    
    data = np.array(data, dtype=np.float32)  # Convert list of arrays to a single NumPy array
    labels = np.array(labels, dtype=np.float32)
    
    return torch.tensor(data, dtype=torch.float32), torch.tensor(labels, dtype=torch.float32)


# Read data
dir = 'C:\\Users\\nicol\\OneDrive - Universitaet Bern\\Dokumente\\unibe\\BME\\Sem_5\\Diabetes Mgmt\\Code\\DiabetsTechMeatDetection\\data'
file = pd.read_csv(os.path.join(dir, 'timewindowed_adults.csv'))
insulin = file["sqInsulinNormalBolus"].to_numpy()
time = file["minutesPastSimStart"].to_numpy()
cgm = file["cgm"].to_numpy()
cho = file["CR"].to_numpy()

# Create samples
series_length = 30
data, labels = split_data(cgm, insulin, series_length)
labels = labels.unsqueeze(1).to(torch.float32)

# Normalization
for row in range(0, len(data)):
    mue = torch.mean(data[row])
    sigma = torch.std(data[row])
    data[row] = (data[row] - mue) / sigma

# Create sets
data_train = data[0:int(0.8 * len(data))]
labels_train = labels[0:int(0.8 * len(data))]

data_val = data[int(0.8 * len(data)):int(0.9 * len(data))]
labels_val = labels[int(0.8 * len(data)):int(0.9 * len(data))]

data_test = data[int(0.9 * len(data)):-1]
labels_test = labels[int(0.9 * len(data)):-1]

# Model
n_steps = series_length
n_features = 1
hidden_size = 25
model = LSTMModel(n_features, hidden_size)
criterion = nn.BCELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# Check if there are any NaN values in the data
nan_in_data = torch.isnan(data_train).any()
nan_in_labels = torch.isnan(labels_train).any()

print("NaN in data:", nan_in_data.item())
print("NaN in labels:", nan_in_labels.item())

data_train[data_train != data_train] = 0  # Replace NaNs with 0
labels_train[labels_train != labels_train] = 0  # Replace NaNs with 0

# Replace infinities with a large finite number or another appropriate value
data_train[torch.isinf(data_train)] = torch.finfo(data_train.dtype).max

# Minoritiy oversampling
data_train_resampled, labels_train_resampled = SMOTE(sampling_strategy=1, random_state=None, k_neighbors=5, n_jobs=None).fit_resample(
    data_train, labels_train
)

# Convert to PyTorch tensors with double precision
data_train_resampled = torch.tensor(data_train_resampled, dtype=torch.float32)
labels_train_resampled = torch.tensor(labels_train_resampled, dtype=torch.float32)


# Training
batch_size = 16
epochs = 10

# Assuming data_train_resampled and labels_train_resampled are already tensors
dataset = torch.utils.data.TensorDataset(data_train_resampled, labels_train_resampled)
data_loader = torch.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle=True)

for epoch in range(epochs):
    total_loss = 0.0
    num_batches = 0

    for batch_data, batch_labels in data_loader:
        optimizer.zero_grad()
        outputs = model(batch_data.unsqueeze(2))
        loss = criterion(outputs, batch_labels.view(-1, 1))
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        num_batches += 1

    average_loss = total_loss / num_batches
    print(f"Epoch {epoch+1}/{epochs}, Average Loss: {average_loss}")
    
# Saving the model
model_save_path = 'C:\\Users\\nicol\\OneDrive - Universitaet Bern\\Dokumente\\unibe\\BME\\Sem_5\\Diabetes Mgmt\\Code\\DiabetsTechMeatDetection\\LSTM_model_adults.pth'
torch.save(model.state_dict(), model_save_path)
print(f"Model saved to {model_save_path}")    


# Model infos
sample_input = torch.randn(1, n_steps, n_features)  # Example input tensor
summary(model, input_data=sample_input)

# Prediction
predict = model(data_val.unsqueeze(2).float())  # Convert to float
predict_test = model(data_test.unsqueeze(2).float())  # Convert to float

# Evaluation
fpr, tpr, thresholds = roc_curve(labels_val, predict.detach().numpy())
fpr_t, tpr_t, thresholds_t = roc_curve(labels_test, predict_test.detach().numpy())

plt.subplot(1, 2, 1)
plt.plot(fpr, tpr, label="validation")
plt.plot(fpr_t, tpr_t, 'r', label="testing")
plt.title("ROC_curve")
plt.xlabel("specifity")
plt.ylabel("sensitivity")
plt.grid()

prec, rec, thresholds2 = precision_recall_curve(labels_val, predict.detach().numpy())
prec_t, rec_t, thresholds2_t = precision_recall_curve(labels_test, predict_test.detach().numpy())

plt.subplot(1, 2, 2)
plt.plot(rec, prec, label="validation")
plt.plot(rec_t, prec_t, 'r', label="testing")
plt.title("precision-recall")
plt.xlabel("Recall")
plt.ylabel("Precision")
plt.legend()
plt.grid()

ROC_area = roc_auc_score(labels_val, predict.detach().numpy())
avg_prec = average_precision_score(labels_val, predict.detach().numpy())
print('area under ROC:', ROC_area, 'average precision:', avg_prec)

opt_index = np.argmax(tpr - fpr)
opt_threshold = thresholds[opt_index]

opt_index2 = np.argmin(np.abs(prec - rec))
opt_threshold2 = thresholds2[opt_index2]
print('optimal threshold is:', opt_threshold)

predict_tresh = (predict >= opt_threshold).numpy()
predict_tresh2 = (predict >= opt_threshold2).numpy()

acc = accuracy_score(labels_val.numpy(), predict_tresh2)

spec_tresh = 1 - fpr[opt_index]
sens_tresh = tpr[opt_index]
prec_tresh = prec[opt_index2]
rec_tresh = rec[opt_index2]

print('accuracy=', acc, 'specificity=', spec_tresh, ' sensitivity=', sens_tresh)
print('precision =', prec_tresh, ' recall =', rec_tresh)

predict_bin = predict_tresh2
labels_val = labels_val.numpy().reshape(predict_bin.shape)
diff = (np.abs(predict_bin - labels_val))
accuracy = 1 - np.sum(diff) / len(diff)

print('Accuracy:', accuracy)
