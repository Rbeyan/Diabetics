import glob, os

import numpy as np
import pandas as pd

PROJECT_HOMEFOLDER=os.getcwd()
PATH_TO_DMMSR_DATASET = 'C:\\Users\\nicol\\OneDrive - Universitaet Bern\\Dokumente\\unibe\\BME\\Sem_5\\Diabetes Mgmt\\Code\\DiabetsTechMeatDetection\\DMMSR_Dataset'
print(PATH_TO_DMMSR_DATASET)

def loadcsv():

    # merge all excel into a dataframe, if it doesnt exist yet
    isFile = os.path.isfile(PATH_TO_DMMSR_DATASET + "/merged.csv")
    if not isFile:
        df_tot = pd.DataFrame()

        print(df_tot.head())
        print(df_tot.shape)

        os.chdir(PATH_TO_DMMSR_DATASET + "/adolecents")
        for file in glob.glob("*.csv"):
            df = pd.read_csv(file)
            df_tot = df_tot._append(df, ignore_index=True)

        os.chdir(PATH_TO_DMMSR_DATASET + "/adults")
        for file in glob.glob("*.csv"):
            df = pd.read_csv(file)
            df_tot = df_tot._append(df, ignore_index=True)

        os.chdir(PATH_TO_DMMSR_DATASET + "/children")
        for file in glob.glob("*.csv"):
            df = pd.read_csv(file)
            df_tot = df_tot._append(df, ignore_index=True)
        df_tot.to_csv(PATH_TO_DMMSR_DATASET + '/merged.csv', index=False)
        print("merged all files together")
    else:
        df_tot = pd.read_csv(PATH_TO_DMMSR_DATASET + '/merged.csv')



    return df_tot

import pandas as pd
import numpy as np
import os

def writetimewindows(df_tot, timewindow):

    # Check if the time-windowed file already exists
    if not os.path.isfile(os.path.join(PATH_TO_DMMSR_DATASET, "timewindowed.csv")):
        # Initialize new columns
        df_tot['timewindow_nr'] = 0
        df_tot['binarization'] = 0

        # Group by 'name'
        df_tot_grouped = df_tot.groupby('name')
        
        modified_groups = []  # List to store modified groups

        for group_name, df_group in df_tot_grouped:
            # Assign time windows
            df_group = df_group.copy()
            df_group['timewindow_nr'] = np.arange(len(df_group)) // timewindow

            # Drop the last time window if its length is not divisible by 'timewindow'
            max_timewindow_nr = df_group['timewindow_nr'].max()
            if len(df_group[df_group['timewindow_nr'] == max_timewindow_nr]) % timewindow != 0:
                df_group = df_group[df_group['timewindow_nr'] != max_timewindow_nr]

            # Group by 'timewindow_nr' and process each subgroup
            modified_subgroups = []  # List to store modified subgroups
            for subgroup_name, df_subgroup in df_group.groupby('timewindow_nr'):
                df_subgroup = df_subgroup.copy()
                if df_subgroup['sqInsulinNormalBolus'].max() > 0:
                    df_subgroup['binarization'] = 1
                modified_subgroups.append(df_subgroup)

            # Concatenate all modified subgroups for this group
            df_subresult = pd.concat(modified_subgroups, axis=0)
            modified_groups.append(df_subresult)

        # Concatenate all modified groups to form the final result
        df_result = pd.concat(modified_groups, axis=0)

        # Save the result to a file
        df_result.to_csv(os.path.join(PATH_TO_DMMSR_DATASET, 'timewindowed.csv'), index=False)
        print("Time-windowed merged file created.")

        return df_result
    else:
        # Load the existing time-windowed file
        return pd.read_csv(os.path.join(PATH_TO_DMMSR_DATASET, 'timewindowed.csv'))


if __name__ == '__main__':
    df_tot=loadcsv()
    print(df_tot.columns)
    df_tot = df_tot[['sqInsulinNormalBolus', 'minutesPastSimStart', 'cgm', 'name']]
    timewindow=15
    #each file has rows 1 to 44640
    df_tot=writetimewindows(df_tot,timewindow)
    # df_tot=binarize(df_tot)
    # df_tot=splitintosets()

    pass


