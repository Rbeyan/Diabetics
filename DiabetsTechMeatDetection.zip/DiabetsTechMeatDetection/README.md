# Diabetes Technologies Meal Detection

**Attention!** DMMSR_Dataset exceeds github-filesize limitations, therefore download dataset individually

Expected filestructure:

.idea
DMMSR_Dataset
	DMMSR_Dataset
		adolescents
		adults
		children
venv
main.py
readme.py
